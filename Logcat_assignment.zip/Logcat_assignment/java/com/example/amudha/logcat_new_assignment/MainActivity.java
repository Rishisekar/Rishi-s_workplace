package com.example.amudha.logcat_new_assignment;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b=(Button)findViewById(R.id.bt);
        Log.v("verbose","rishi");
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = 10 / 2;
                Log.e("Div answer", "error");
                for (int i = 0; i < 3; i++) {
                    Log.d("urtag", "iteration " + i);
            }

            Log.i("info","division is successful "+a);
                Log.v("verbosetag","rishi2");
            }

        });

         }
    }


